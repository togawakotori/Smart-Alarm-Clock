i="$1"
echo yes|./demo/bin/tts_sample $i
aplay ./tts_sample.wav


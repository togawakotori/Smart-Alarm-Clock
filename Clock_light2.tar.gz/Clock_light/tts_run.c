#include<stdio.h>
#include<stdlib.h>
int main(){
	system("/home/pi/iot/tts_make.sh");
	return 0;
}

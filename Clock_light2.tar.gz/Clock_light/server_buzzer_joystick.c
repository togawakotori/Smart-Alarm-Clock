#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <time.h> 
#include <netdb.h>
#include <pthread.h>
#include <wiringPi.h>
#include <softTone.h>
#include <pcf8591.h>
 
#define BuzPin    0
#define TouchPin  1
#define PCF       120 

#define  CL1  131
#define  CL2  147
#define  CL3  165
#define  CL4  175
#define  CL5  196
#define  CL6  221
#define  CL7  248

#define  CM1  262
#define  CM2  294
#define  CM3  330
#define  CM4  350
#define  CM5  393
#define  CM6  441
#define  CM7  495

#define  CH1  525
#define  CH2  589
#define  CH3  661
#define  CH4  700
#define  CH5  786
#define  CH6  882
#define  CH7  990

#define BUFFER_SIZE 8

int AIN0 = PCF + 0;
int AIN1 = PCF + 1;
int AIN2 = PCF + 2;
 
char *state[6] = {"home", "down","up" ,"left", "right", "pressed"};

//int avg_x=220;
//int avg_y=200;
int avg_x,avg_y,avg_flag=1;
int dev=20;

int song_1[] = {CM3,CM3,CM4,CM5,CM5,CM4,CM3,CM2};
int beat_1[] = {1,1,1,1,1,1,1,1};

int buf[BUFFER_SIZE];

    int listenfd = 0, connfd = 0;
    int total_request = 0;
    struct sockaddr_in serv_addr; 

    char sendBuff[1025];
    time_t sys; 
    time_t input;
    struct tm input_;

pthread_t tid[3];

int direction(void);
void * buzz(void);
void * joystick(void);
void * neverstop(void); 
int connection(void);
int main(int argc, char *argv[])
{
    listenfd = socket(AF_INET, SOCK_STREAM, 0);
    memset(&serv_addr, '0', sizeof(serv_addr));
    memset(sendBuff, '0', sizeof(sendBuff)); 

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    serv_addr.sin_port = htons(5000); 

    bind(listenfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)); 

    listen(listenfd, 10); 
       
       if(wiringPiSetup() == -1){ //when initialize wiring failed,print messageto screen
		printf("setup wiringPi failed !");
		return 1; 
	}

	if(softToneCreate(BuzPin) == -1){
		printf("setup softTone failed !");
		return 1; 
	}
       
    pcf8591Setup (PCF, 0x48);// Setup pcf8591 on base pin 120, and address 0x48

    pinMode(TouchPin, INPUT);

 
    int err[3] = {0,0,0};
    void *status;
   err[0] = pthread_create(&(tid[0]), NULL, &buzz, NULL); 
   err[1] = pthread_create(&(tid[1]), NULL, &joystick, NULL);
   err[2] = pthread_create(&(tid[2]), NULL, &neverstop, NULL);
   pthread_join(tid[2], &status);
   return 0;
 
}
void * neverstop(void){ while (1);}
int connection(void){
       connfd = accept(listenfd, (struct sockaddr*)NULL, NULL); 
       memset(buf,0,sizeof(buf));
       recv(connfd, buf, sizeof(buf),0);
     sys = time(NULL);
      buf[sizeof(buf)+1]=0;
      printf("%d\n",sizeof(buf));
       printf("%d %d %d %d %d %d %d\n",buf[0],buf[1],buf[2],buf[3],buf[4],buf[5],buf[6]);
       close(connfd);
  //     sleep(1);
      return buf[0];
}

void * buzz(void){
int cookie[50];
while(1){
int i=0,record=0,flag=1;
FILE * clock;
clock=fopen("/home/pi/Documents/clock.txt","r");
 
char *buf=(char*)malloc(100*sizeof(char));
while (fgets(buf,100,clock)!=NULL)

{
    strptime(buf, "%Y-%m-%d %H:%M:%S", &input_);
    input_.tm_isdst = -1;
    input = mktime(&input_);
    if ((abs(difftime(time(NULL), input))<60)&&(cookie[i]!=-1)) cookie[i]=1;
    i++;
}
fclose(clock);//sleep(1);
//printf("%d %d %d %d %d %d\n",cookie[0],cookie[1],cookie[2],cookie[3],cookie[4],cookie[5]);
int i_size=i;  
   //   
//printf("%d\n",i_size);   
i=0;
while ((i<i_size+1)&&(cookie[i]!=1)) i++; 
//printf("COOK %d\n",i);
int j=i;
if (i>=i_size) flag=0;

while (flag){
if (digitalRead(TouchPin)==0)
  	{
          record=0;
          softToneWrite(BuzPin, song_1[i%(sizeof(song_1)/4)]); 
	  delay(beat_1[i%(sizeof(song_1)/4)] * 300);
        }		
       else {
         if (record++>6) {cookie[j]=-1; flag=0;}
         softToneWrite(BuzPin, 0);  
         delay(50);	
       }
i++;
}
sleep(1);
}
}

void * joystick(void){
int tmp, status = 0;
direction();
while (1){
	tmp = direction();  
     printf("test TOUCH%d DIRECTION%d\n",digitalRead(TouchPin),tmp);
	if (tmp != status)
		{     if ((tmp==1)) {system("./tts_make.sh 0");}
                      if ((tmp==2)) 
                          {//weather report
                        connection(); 
                        printf("WAITING %d %d\n",buf[1], time(NULL));
                         while (abs(buf[1]-time(NULL))>5)  connection(); 
                         FILE * weather=fopen("./weather.txt","w+");
			 fprintf(weather, (buf[7]==0)?"今天的天气是%d.%d度，湿度是百分之%d.%d，下雨\n":"今天的天气是%d.%d度，湿度是百分之%d.%d，不下雨\n",buf[4],buf[5],buf[2],buf[3]);
                         fclose(weather);
                         system("./tts_make.sh 1");
                            }  
                      if (tmp==3) {int i; for (i=0;i<8;i++) beat_1[i]++;}
			printf("%s\n", state[tmp]);
			status = tmp;
		}
}

}
 

int direction(void){
	int x, y, b;
	int tmp=0;
	x = analogRead(AIN1);
	y = analogRead(AIN0);
	b = analogRead(AIN2);
        if (avg_flag) {avg_x=x;avg_y=y;avg_flag=0;}
       printf("COOR %d %d %d\n",x,y,b);
        if (y-avg_y<-dev)  tmp = 1;		// down
 	if (y-avg_y>+dev) tmp = 2;		// up
        if (x-avg_x>+dev) tmp = 3;		// left
	if (x-avg_x<-dev)  tmp = 4;		// right
	if (b == 0) tmp = 5;		// button preesd
	if (x-avg_x<10 && x-avg_x>-10 && y-avg_y<10 && y-avg_y>-10 && b !=0)
		tmp = 0;		// home position
	
	return tmp;
}


